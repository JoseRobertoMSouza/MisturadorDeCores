#include <pic18f4520.h>
#include "config.h"
#include "bits.h"
#include "lcd.h"
#include "keypad.h"
#include "atraso.h"

#define L_L3 L_L1+16
#define L_L4 L_L2+16


//Fun��es
void lcd_Layout(void);
void menu(void);
void resultado(void);


//Vari�veis
unsigned char tecla=0;
int m=0, i, lcd, cor;

int mistura[3] = {0,0,0};



void main() {


	// Configura��o inicial do sistema
    TRISA = 0xC3;
    TRISB = 0x03;
    TRISC = 0x00;
    TRISD = 0x00;
    TRISE = 0x00;

    lcd_init();
   
    lcd_cmd(L_CLR);
    lcd_cmd(L_L1+2);
    lcd_str("Projetado na");
    lcd_cmd(L_L2+2);
    lcd_str("UNIFEI");
    lcd_cmd(L_L3+2);
    lcd_str("Pelo aluno");
    lcd_cmd(L_L4+2);
    lcd_str("Jose Roberto");
    
    atraso_ms (1000);
    
	//loop de fun��es principal
    for(;;){
    
    lcd_Layout();
    
    menu();
    
    
}
}
// Fun��o de exibi��o no display LCD
void lcd_Layout(void){
    lcd_cmd(L_CLR);
    switch(lcd){
        
        case 0:
            lcd_cmd(L_CLR);
            lcd_cmd(L_L1);
            lcd_str("Definir 1a");
            lcd_str(" cor:");
            
            lcd_cmd(L_L2);
            switch(cor){
                case 0:
                lcd_str("Ciano");  
                break;
                case 1:
                lcd_str("Magenta");   
                break;
                case 2:
                lcd_str("Amarelo");
                break;
            }
            
            lcd_cmd(L_L4);
            lcd_str("1-4:<>*:ok0:conf");
        break;
        case 1:
            lcd_cmd(L_CLR);
            lcd_cmd(L_L1);
            lcd_str("Definir 2a");
            lcd_str(" cor:");
            
            lcd_cmd(L_L2);
            switch(cor){
                case 0:
                lcd_str("Ciano");  
                break;
                case 1:
                lcd_str("Magenta");   
                break;
                case 2:
                lcd_str("Amarelo");
                break;
            }
            
            lcd_cmd(L_L4);
            lcd_str("1-4:<>*:ok0:conf");
            
            
        break;
        case 2:
            lcd_cmd(L_CLR);
            lcd_cmd(L_L1);
            lcd_str("Definir 3a");
            lcd_str(" cor:");
            
            lcd_cmd(L_L2);
            switch(cor){
                case 0:
                lcd_str("Ciano");  
                break;
                case 1:
                lcd_str("Magenta");   
                break;
                case 2:
                lcd_str("Amarelo");
                break;
            }
            
            lcd_cmd(L_L4);
            lcd_str("1-4:<>*:ok0:conf");
            
            
        break;
        case 3:
            lcd_cmd(L_CLR);
            lcd_cmd(L_L1);
            lcd_str("Resultado:");
            
            lcd_cmd(L_L2);
            resultado();        
            
            lcd_cmd(L_L3);
            lcd_str("aperte 0 para");
            lcd_cmd(L_L4);
            lcd_str("continuar.");
            
        break;
        case 4:
            lcd_cmd(L_CLR);
            lcd_cmd(L_L1);
            lcd_str("Obrigado!!!");
            
            lcd_cmd(L_L3);
            lcd_str("Aperte RST");
            
            lcd_cmd(L_L4);
            lcd_str("p/ reiniciar.");
        break;

    } 
}
// Fun��o de mapeamento de fun��es do teclado matricial
void menu(void){
    
    
    while (!kpRead()){
        
    kpDebounce();
    
    if (kpRead() != tecla){
        tecla = kpRead();
            
        if(bitTst(tecla, 3)) {//tecla 1
            if(m == 0 || m ==  1 || m == 2 ){
                if(cor < 2){
                   cor++; 
                }
            }
        }
        if(bitTst(tecla, 2)) {//tecla 4
            if(m == 0 || m ==  1 || m == 2 ){
                if(cor > 0){
                   cor--; 
                }
            }
        }   
        if(bitTst(tecla, 0)) {//aster�sco
            if(m == 0 || m ==  1 || m == 2 ){
                lcd = 3;
            }
        }
        
        
        if(bitTst(tecla, 4)) {//tecla 0
            if(m == 0 || m ==  1 || m == 2 ){
                if (cor == 0){
                    mistura[cor] ++;
                    
                }
                else if (cor == 1){
                    mistura[cor] ++;
                    
                }
                else if (cor == 2){
                    mistura[cor] ++;
                    
                }
                
        }
            if(lcd < 4){
                
                bitSet(PORTC, 0);
                atraso_ms(500);
                bitClr(PORTC, 0);
                
                lcd++;
                m++;
                }
        }
        if(lcd == 3){
                
                bitSet(PORTC, 2);
                atraso_ms(500);
                bitClr(PORTC, 2);
                }
        }
          
    }

    for (i=0; i<=10; i++){
        kpDebounce();
    }   
    
}
// Configura��o do resultado da mistura de cores
void resultado(void){
    if (mistura[0] == 3){
    lcd_str("Ciano");    
    }
    else if (mistura[1] == 3){
    lcd_str("Magenta");    
    }
    else if (mistura[2] == 3){
    lcd_str("Amarelo");    
    }
    else if (mistura [0] == 2){
        if (mistura [1] == 1){
        lcd_str("Azul Celeste");    
        }
        if (mistura [2] == 1){
        lcd_str("Esmeralda");    
        }
            
    }
    else if (mistura [1] == 2){
        if (mistura [0] == 1){
        lcd_str("Roxo");    
        }
        if (mistura [2] == 1){
        lcd_str("Rosa");    
        }
            
    }
    else if (mistura [2] == 2){
        if (mistura [1] == 1){
        lcd_str("Laranja");    
        }
        if (mistura [0] == 1){
        lcd_str("Verde Lima");    
        }
            
    }
    else if (mistura [0] == 1 && mistura [1] == 1 && mistura [2] == 0){
    lcd_str("Azul Marinho");       
    }
    else if (mistura [0] == 1 && mistura [1] == 0 && mistura [2] == 1){
    lcd_str("Verde");       
    }
    else if (mistura [0] == 0 && mistura [1] == 1 && mistura [2] == 1){
    lcd_str("Vermelho");       
    }
    else if (mistura [0] == 1 && mistura [1] == 1 && mistura [2] == 1){
    lcd_str("Branco");       
    }
    else if (mistura [0] == 1 && mistura [1] == 0 && mistura [2] == 0){
    lcd_str("Ciano");       
    }
    else if (mistura [0] == 0 && mistura [1] == 0 && mistura [2] == 1){
    lcd_str("Amarelo");       
    }
    else if (mistura [0] == 0 && mistura [1] == 1 && mistura [2] == 0){
    lcd_str("Magenta");       
    }
    else{
    lcd_str("Nenhum");    
    }
        
}

